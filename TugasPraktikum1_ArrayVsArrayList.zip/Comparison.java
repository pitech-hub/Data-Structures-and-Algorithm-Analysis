import java.util.ArrayList;
import java.util.Random;

/**
 * Comparison
 * ----------
 * Ties ArrayOperations and ArrayListOperations together, then benchmarks
 * them against each other using System.nanoTime(). Two rounds are run:
 *
 *   1. A small, fixed dataset (5 elements) that reproduces the exact
 *      example output described in the assignment sheet.
 *   2. A larger, randomly generated dataset (1000 elements) so the
 *      performance difference between Array and ArrayList becomes
 *      visible in practice.
 *
 * Results of round 2 are printed as a simple text table.
 */
public class Comparison {

    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println(" BAGIAN 1: Contoh Output (dataset kecil) ");
        System.out.println("=========================================");
        demoSmallDataset();

        System.out.println();
        System.out.println("=========================================");
        System.out.println(" BAGIAN 2: Perbandingan Kinerja (n = 1000)");
        System.out.println("=========================================");
        benchmarkLargeDataset(1000);
    }

    // ---------------------------------------------------------------
    // Bagian 1: reproduces the sample output shown in the assignment
    // ---------------------------------------------------------------
    private static void demoSmallDataset() {
        int[] arr = {10, 20, 30, 40, 50};
        ArrayList<Integer> list = new ArrayList<>();
        for (int v : arr) list.add(v);

        System.out.println("Array Traversal: " + ArrayOperations.traverse(arr));
        System.out.println("ArrayList Traversal: " + ArrayListOperations.traverse(list));

        long t1 = System.nanoTime();
        int idxArr = ArrayOperations.binarySearch(arr, 30);
        long t2 = System.nanoTime();
        System.out.println("Pencarian 30 dalam Array: Ditemukan di indeks " + idxArr);

        long t3 = System.nanoTime();
        int idxList = ArrayListOperations.search(list, 30);
        long t4 = System.nanoTime();
        System.out.println("Pencarian 30 dalam ArrayList: Ditemukan di indeks " + idxList);

        arr = ArrayOperations.insert(arr, 2, 25);
        System.out.println("Array setelah penyisipan elemen 25: " + ArrayOperations.traverse(arr));

        ArrayListOperations.add(list, 2, 25);
        System.out.println("ArrayList setelah penyisipan elemen 25: " + ArrayListOperations.traverse(list));

        System.out.printf("Waktu eksekusi pencarian pada Array: %.4f ms%n", (t2 - t1) / 1_000_000.0);
        System.out.printf("Waktu eksekusi pencarian pada ArrayList: %.4f ms%n", (t4 - t3) / 1_000_000.0);
    }

    // ---------------------------------------------------------------
    // Bagian 2: real benchmark with a larger dataset
    //
    // The JIT compiler optimizes "hot" code after it has run a few
    // times, so a single measurement can be noisy. To get numbers that
    // are representative, we (a) run a short warm-up phase that is
    // discarded, then (b) run TRIALS repetitions and report the average.
    // ---------------------------------------------------------------
    private static final int TRIALS = 50;

    private static void benchmarkLargeDataset(int n) {
        int[] baseArray = generateSortedArray(n);
        ArrayList<Integer> baseList = toArrayList(baseArray);

        // warm-up (results discarded) so JIT compilation doesn't skew Trial #1
        for (int i = 0; i < 10; i++) {
            timeArrayTraverse(baseArray);
            timeListTraverse(baseList);
            timeArrayLinearSearch(baseArray);
            timeListSearch(baseList);
            timeArrayBinarySearch(baseArray);
            timeArrayInsert(baseArray);
            timeListInsert(baseList);
            timeArrayDelete(baseArray);
            timeListDelete(baseList);
        }

        double traverseArr = 0, traverseList = 0, linSearchArr = 0, linSearchList = 0;
        double binSearchArr = 0, insertArr = 0, insertList = 0, deleteArr = 0, deleteList = 0;

        for (int i = 0; i < TRIALS; i++) {
            traverseArr += timeArrayTraverse(baseArray);
            traverseList += timeListTraverse(baseList);
            linSearchArr += timeArrayLinearSearch(baseArray);
            linSearchList += timeListSearch(baseList);
            binSearchArr += timeArrayBinarySearch(baseArray);
            insertArr += timeArrayInsert(baseArray);
            insertList += timeListInsert(baseList);
            deleteArr += timeArrayDelete(baseArray);
            deleteList += timeListDelete(baseList);
        }

        printTable(traverseArr / TRIALS, traverseList / TRIALS,
                linSearchArr / TRIALS, linSearchList / TRIALS,
                binSearchArr / TRIALS,
                insertArr / TRIALS, insertList / TRIALS,
                deleteArr / TRIALS, deleteList / TRIALS);
        System.out.println("\n(Setiap angka adalah rata-rata dari " + TRIALS + " kali percobaan, setelah warm-up JIT)");
    }


    // ---- helpers to build test data ----

    private static int[] generateSortedArray(int n) {
        Random rand = new Random(42); // fixed seed -> reproducible results
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = rand.nextInt(n * 10);
        java.util.Arrays.sort(arr); // sorted so binarySearch is valid
        return arr;
    }

    private static ArrayList<Integer> toArrayList(int[] arr) {
        ArrayList<Integer> list = new ArrayList<>();
        for (int v : arr) list.add(v);
        return list;
    }

    // ---- timed operations (each returns milliseconds) ----

    private static double timeArrayTraverse(int[] arr) {
        long t1 = System.nanoTime();
        ArrayOperations.traverse(arr);
        long t2 = System.nanoTime();
        return (t2 - t1) / 1_000_000.0;
    }

    private static double timeListTraverse(ArrayList<Integer> list) {
        long t1 = System.nanoTime();
        ArrayListOperations.traverse(list);
        long t2 = System.nanoTime();
        return (t2 - t1) / 1_000_000.0;
    }

    private static double timeArrayLinearSearch(int[] arr) {
        int target = arr[arr.length - 1]; // worst case: last element
        long t1 = System.nanoTime();
        ArrayOperations.linearSearch(arr, target);
        long t2 = System.nanoTime();
        return (t2 - t1) / 1_000_000.0;
    }

    private static double timeArrayBinarySearch(int[] arr) {
        int target = arr[arr.length - 1];
        long t1 = System.nanoTime();
        ArrayOperations.binarySearch(arr, target);
        long t2 = System.nanoTime();
        return (t2 - t1) / 1_000_000.0;
    }

    private static double timeListSearch(ArrayList<Integer> list) {
        int target = list.get(list.size() - 1);
        long t1 = System.nanoTime();
        ArrayListOperations.search(list, target);
        long t2 = System.nanoTime();
        return (t2 - t1) / 1_000_000.0;
    }

    private static double timeArrayInsert(int[] arr) {
        long t1 = System.nanoTime();
        ArrayOperations.insert(arr, arr.length / 2, 999);
        long t2 = System.nanoTime();
        return (t2 - t1) / 1_000_000.0;
    }

    private static double timeListInsert(ArrayList<Integer> list) {
        @SuppressWarnings("unchecked")
        ArrayList<Integer> copy = (ArrayList<Integer>) list.clone();
        long t1 = System.nanoTime();
        ArrayListOperations.add(copy, copy.size() / 2, 999);
        long t2 = System.nanoTime();
        return (t2 - t1) / 1_000_000.0;
    }

    private static double timeArrayDelete(int[] arr) {
        long t1 = System.nanoTime();
        ArrayOperations.delete(arr, arr.length / 2);
        long t2 = System.nanoTime();
        return (t2 - t1) / 1_000_000.0;
    }

    private static double timeListDelete(ArrayList<Integer> list) {
        @SuppressWarnings("unchecked")
        ArrayList<Integer> copy = (ArrayList<Integer>) list.clone();
        long t1 = System.nanoTime();
        copy.remove(copy.size() / 2);
        long t2 = System.nanoTime();
        return (t2 - t1) / 1_000_000.0;
    }

    // ---- reporting ----

    private static void printTable(double traverseArr, double traverseList,
                                    double linSearchArr, double linSearchList,
                                    double binSearchArr,
                                    double insertArr, double insertList,
                                    double deleteArr, double deleteList) {
        System.out.println();
        System.out.printf("%-30s %15s %15s%n", "Operasi", "Array (ms)", "ArrayList (ms)");
        System.out.println("--------------------------------------------------------------");
        System.out.printf("%-30s %15.4f %15.4f%n", "Traversal", traverseArr, traverseList);
        System.out.printf("%-30s %15.4f %15.4f%n", "Pencarian (linear)", linSearchArr, linSearchList);
        System.out.printf("%-30s %15.4f %15s%n", "Pencarian (binary, Array only)", binSearchArr, "-");
        System.out.printf("%-30s %15.4f %15.4f%n", "Penyisipan (tengah)", insertArr, insertList);
        System.out.printf("%-30s %15.4f %15.4f%n", "Penghapusan (tengah)", deleteArr, deleteList);
    }
}
