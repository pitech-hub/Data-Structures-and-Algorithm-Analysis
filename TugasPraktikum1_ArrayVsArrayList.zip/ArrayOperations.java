import java.util.Arrays;

/**
 * ArrayOperations
 * ----------------
 * Implements the basic operations required on a plain Java array:
 * traversal, searching (linear & binary), insertion, and deletion.
 *
 * Insertion and deletion return a NEW array (Java arrays are fixed-size),
 * and use System.arraycopy() for efficient bulk copying instead of
 * manual element-by-element loops.
 */
public class ArrayOperations {

    /**
     * Traversal: builds a readable String representation of the array,
     * equivalent to visiting every element in order.
     */
    public static String traverse(int[] arr) {
        return Arrays.toString(arr);
    }

    /**
     * Linear Search: checks every element one by one until the target
     * is found. Works on both sorted and unsorted arrays.
     * Time complexity: O(n)
     *
     * @return index of target, or -1 if not found
     */
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Binary Search: repeatedly halves the search interval.
     * REQUIRES the array to be sorted in ascending order.
     * Time complexity: O(log n)
     *
     * @return index of target, or -1 if not found
     */
    public static int binarySearch(int[] arr, int target) {
        int low = 0, high = arr.length - 1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1;
    }

    /**
     * Insertion: inserts `value` at position `index`, shifting subsequent
     * elements to the right. Because arrays are fixed-size in Java, a new
     * array (length + 1) is allocated and System.arraycopy() is used to
     * efficiently copy the "before" and "after" segments around the gap.
     */
    public static int[] insert(int[] arr, int index, int value) {
        if (index < 0 || index > arr.length) {
            throw new IndexOutOfBoundsException("Invalid insertion index: " + index);
        }
        int[] result = new int[arr.length + 1];
        // copy the part before the insertion point
        System.arraycopy(arr, 0, result, 0, index);
        // place the new value
        result[index] = value;
        // copy the remaining part, shifted one position to the right
        System.arraycopy(arr, index, result, index + 1, arr.length - index);
        return result;
    }

    /**
     * Deletion: removes the element at position `index`, shifting subsequent
     * elements to the left. Returns a new array (length - 1).
     */
    public static int[] delete(int[] arr, int index) {
        if (index < 0 || index >= arr.length) {
            throw new IndexOutOfBoundsException("Invalid deletion index: " + index);
        }
        int[] result = new int[arr.length - 1];
        // copy the part before the deleted element
        System.arraycopy(arr, 0, result, 0, index);
        // copy the part after the deleted element, shifted one position left
        System.arraycopy(arr, index + 1, result, index, arr.length - index - 1);
        return result;
    }

    /** Small demo matching the assignment's example output. */
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50};
        System.out.println("Array Traversal: " + traverse(arr));
        System.out.println("Pencarian 30 dalam Array: Ditemukan di indeks " + binarySearch(arr, 30));

        int[] afterInsert = insert(arr, 2, 25);
        System.out.println("Array setelah penyisipan elemen 25: " + traverse(afterInsert));

        int[] afterDelete = delete(afterInsert, 2);
        System.out.println("Array setelah penghapusan elemen 25: " + traverse(afterDelete));
    }
}
