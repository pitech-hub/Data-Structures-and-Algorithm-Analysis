import java.util.ArrayList;
import java.util.Collections;

/**
 * ArrayListOperations
 * --------------------
 * Implements the basic operations required on a Java ArrayList:
 * adding elements, removing elements, searching, and sorting.
 *
 * Unlike a plain array, ArrayList resizes itself dynamically, so these
 * methods mutate the list in place and return it for convenience.
 */
public class ArrayListOperations {

    /** Traversal: returns a readable String representation of the list. */
    public static String traverse(ArrayList<Integer> list) {
        return list.toString();
    }

    /** Adds an element to the end of the list. */
    public static ArrayList<Integer> add(ArrayList<Integer> list, int value) {
        list.add(value);
        return list;
    }

    /** Inserts an element at a specific position (mirrors Array.insert). */
    public static ArrayList<Integer> add(ArrayList<Integer> list, int index, int value) {
        list.add(index, value);
        return list;
    }

    /**
     * Removes the first occurrence of `value` from the list.
     * Returns true if an element was removed.
     */
    public static boolean remove(ArrayList<Integer> list, int value) {
        // Must box to Integer explicitly - list.remove(int) would remove by INDEX,
        // while list.remove(Integer) removes by VALUE.
        return list.remove(Integer.valueOf(value));
    }

    /**
     * Linear search through the ArrayList using indexOf(), which internally
     * scans element by element - conceptually equivalent to ArrayOperations.linearSearch.
     * Time complexity: O(n)
     */
    public static int search(ArrayList<Integer> list, int value) {
        return list.indexOf(value);
    }

    /**
     * Sorts the list in ascending order using Collections.sort(),
     * which runs a Dual-Pivot Quicksort / TimSort-based algorithm.
     * Time complexity: O(n log n)
     */
    public static void sort(ArrayList<Integer> list) {
        Collections.sort(list);
    }

    /** Small demo matching the assignment's example output. */
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        for (int v : new int[]{10, 20, 30, 40, 50}) list.add(v);

        System.out.println("ArrayList Traversal: " + traverse(list));
        System.out.println("Pencarian 30 dalam ArrayList: Ditemukan di indeks " + search(list, 30));

        add(list, 2, 25);
        System.out.println("ArrayList setelah penyisipan elemen 25: " + traverse(list));

        remove(list, 25);
        System.out.println("ArrayList setelah penghapusan elemen 25: " + traverse(list));
    }
}
